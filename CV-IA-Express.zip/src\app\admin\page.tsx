import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';

export default async function AdminPanel() {
  const session = await auth();

  // Very basic authorization for MVP (should be checked properly)
  if (!session?.user?.email) {
    redirect('/login');
  }

  const userCount = await prisma.user.count();
  const cvCount = await prisma.cV.count();
  
  const recentUsers = await prisma.user.findMany({
    take: 5,
    orderBy: { id: 'desc' }
  });

  return (
    <div className="container" style={{padding: '5rem 1.5rem', minHeight: '80vh'}}>
      <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '3rem', paddingBottom: '2rem', borderBottom: '1px solid var(--border-color)'}}>
        <div>
          <h1 style={{fontSize: '2.5rem', marginBottom: '0.5rem'}}>Panneau d'Administration</h1>
          <p className="text-muted">Statistiques et gestion de la plateforme.</p>
        </div>
      </div>

      <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '2rem', marginBottom: '4rem'}}>
        <div style={{background: 'var(--bg-light-grey)', padding: '2rem', borderRadius: '1rem', border: '1px solid var(--border-color)'}}>
           <h3 style={{color: 'var(--text-muted)', fontSize: '1rem', marginBottom: '0.5rem'}}>Utilisateurs Totaux</h3>
           <div style={{fontSize: '3rem', fontWeight: 800, color: 'var(--text-main)'}}>{userCount}</div>
        </div>
        <div style={{background: 'var(--bg-light-grey)', padding: '2rem', borderRadius: '1rem', border: '1px solid var(--border-color)'}}>
           <h3 style={{color: 'var(--text-muted)', fontSize: '1rem', marginBottom: '0.5rem'}}>CV Générés</h3>
           <div style={{fontSize: '3rem', fontWeight: 800, color: 'var(--accent-blue)'}}>{cvCount}</div>
        </div>
        <div style={{background: 'var(--bg-light-grey)', padding: '2rem', borderRadius: '1rem', border: '1px solid var(--border-color)'}}>
           <h3 style={{color: 'var(--text-muted)', fontSize: '1rem', marginBottom: '0.5rem'}}>Revenus du mois</h3>
           <div style={{fontSize: '3rem', fontWeight: 800, color: '#10b981'}}>€0.00</div>
        </div>
      </div>

      <h2>Derniers Inscrits</h2>
      <div style={{marginTop: '2rem', background: 'var(--bg-color)', border: '1px solid var(--border-color)', borderRadius: '1rem', overflow: 'hidden'}}>
         <table style={{width: '100%', borderCollapse: 'collapse', textAlign: 'left'}}>
            <thead style={{background: 'var(--bg-light-grey)'}}>
               <tr>
                 <th style={{padding: '1rem 1.5rem', borderBottom: '1px solid var(--border-color)'}}>Email</th>
                 <th style={{padding: '1rem 1.5rem', borderBottom: '1px solid var(--border-color)'}}>Plan</th>
                 <th style={{padding: '1rem 1.5rem', borderBottom: '1px solid var(--border-color)'}}>Statut</th>
               </tr>
            </thead>
            <tbody>
              {recentUsers.length === 0 ? (
                <tr>
                   <td colSpan={3} style={{padding: '2rem', textAlign: 'center', color: 'var(--text-muted)'}}>Aucun utilisateur pour le moment</td>
                </tr>
              ) : recentUsers.map(u => (
                <tr key={u.id}>
                  <td style={{padding: '1rem 1.5rem', borderBottom: '1px solid var(--border-color)'}}>{u.email}</td>
                  <td style={{padding: '1rem 1.5rem', borderBottom: '1px solid var(--border-color)'}}>
                    <span style={{background: u.plan==='premium'?'rgba(0,86,255,0.1)':'#f1f5f9', color: u.plan==='premium'?'var(--accent-blue)':'inherit', padding: '0.25rem 0.5rem', borderRadius: '0.25rem', fontSize: '0.8rem', fontWeight: 600, textTransform: 'uppercase'}}>{u.plan}</span>
                  </td>
                  <td style={{padding: '1rem 1.5rem', borderBottom: '1px solid var(--border-color)'}}>✅ Actif</td>
                </tr>
              ))}
            </tbody>
         </table>
      </div>
    </div>
  );
}
