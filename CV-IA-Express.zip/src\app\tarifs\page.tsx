"use client";

import Link from 'next/link';
import './page.css';
import { useState } from 'react';

export default function Tarifs() {
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async (priceId: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priceId })
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else if (data.error) {
        alert("Erreur: " + data.error);
        if (data.error === "Non autorisé") window.location.href = '/login';
      }
    } catch (err) {
      console.error(err);
      alert("Erreur lors de la redirection vers le paiement.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container tarifs-container fade-in">
      <div className="tarifs-header">
        <h1>Investis dans ton avenir professionnel</h1>
        <p className="text-muted">Des offres simples, transparentes et rentabilisées dès ton premier salaire.</p>
      </div>

      <div className="tarifs-grid">
        {/* GRATUIT */}
        <div className="tarif-card">
          <div className="tarif-name">Gratuit</div>
          <div className="tarif-price">0€</div>
          <p className="tarif-desc">Pour tester la puissance de notre IA.</p>
          <ul className="tarif-features">
            <li>✔️ 1 CV simple généré</li>
            <li>✔️ Aperçu standard</li>
            <li className="disabled">❌ Pas de PDF Haute Définition</li>
            <li className="disabled">❌ Pas de lettre de motivation</li>
          </ul>
          <Link href="/cv" className="btn btn-outline" style={{width: '100%'}}>Créer un CV gratuit</Link>
        </div>

        {/* PREMIUM */}
        <div className="tarif-card premium fade-in">
          <div className="premium-badge">Le plus populaire</div>
          <div className="tarif-name">Premium</div>
          <div className="tarif-price">7,99€<span className="period">/unique</span></div>
          <p className="tarif-desc">La formule idéale pour trouver un emploi rapidement.</p>
          <ul className="tarif-features">
            <li>✔️ CV premium illimité</li>
            <li>✔️ Export PDF HD</li>
            <li>✔️ Création de Lettres de motivation</li>
            <li>✔️ 10 modèles de design pro</li>
            <li>✔️ Sans publicité</li>
            <li>✔️ Sauvegarde Cloud</li>
          </ul>
          <button 
             onClick={() => handleSubscribe('price_premium_id')} 
             className="btn btn-primary" 
             style={{width: '100%'}}
             disabled={loading}
          >
            {loading ? "Chargement..." : "Commencer Premium"}
          </button>
        </div>

        {/* PRO */}
        <div className="tarif-card">
          <div className="tarif-name">Pro</div>
          <div className="tarif-price">14,99€<span className="period">/unique</span></div>
          <p className="tarif-desc">Pour mettre toutes les chances de ton côté.</p>
          <ul className="tarif-features">
            <li>✔️ <b>Tout du forfait Premium</b></li>
            <li>✔️ Analyse CV IA</li>
            <li>✔️ Préparation d'entretien IA</li>
          </ul>
          <button 
             onClick={() => handleSubscribe('price_pro_id')} 
             className="btn btn-outline" 
             style={{width: '100%'}}
             disabled={loading}
          >
            Choisir Pro
          </button>
        </div>
      </div>
    </div>
  );
}
