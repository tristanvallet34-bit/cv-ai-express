import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import Stripe from 'stripe';

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
    }

    const body = await req.json();
    const { priceId } = body; // Price ID from frontend

    if (!process.env.STRIPE_SECRET_KEY) {
      // Mock mode since no API key is set
      console.log("[STRIPE MOCK] User attempting to buy", priceId);
      return NextResponse.json({ url: '/dashboard?mock_success=true' });
    }

    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: '2025-02-24.acacia',
    });

    const checkoutSession = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      customer_email: session.user.email,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${process.env.NEXTAUTH_URL}/dashboard?success=true`,
      cancel_url: `${process.env.NEXTAUTH_URL}/tarifs?canceled=true`,
    });

    return NextResponse.json({ url: checkoutSession.url });

  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
