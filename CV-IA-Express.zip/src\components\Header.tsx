import Link from 'next/link';
import './Header.css';
import { auth, signOut } from '@/auth';

export default async function Header() {
  const session = await auth();

  return (
    <header className="header">
      <div className="container header-container">
        <Link href="/" className="logo">
          CV IA <span className="text-accent">Express</span>
        </Link>
        
        <nav className="nav-links">
          <Link href="/">Accueil</Link>
          <Link href="/cv" className="nav-highlight">Créer mon CV</Link>
          <Link href="/lettre">Lettre IA</Link>
          <Link href="/tarifs">Tarifs</Link>
          <Link href="/exemples">Exemples</Link>
          <Link href="/blog">Blog</Link>
        </nav>

        <div className="header-actions">
          {session?.user ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <Link href="/dashboard" className="login-link">Mon Espace</Link>
              <form action={async () => {
                "use server";
                await signOut({ redirectTo: "/" });
              }}>
                <button type="submit" className="btn btn-outline" style={{padding: '0.5rem 1rem'}}>Déconnexion</button>
              </form>
            </div>
          ) : (
            <>
              <Link href="/login" className="login-link">Connexion</Link>
              <Link href="/cv" className="btn btn-primary">Créer mon CV Gratuitement</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
