import Link from 'next/link';

export default function Entretien() {
  return (
    <div className="container" style={{padding: '5rem 1.5rem', textAlign: 'center', minHeight: '60vh'}}>
      <h1 style={{fontSize: '2.5rem', marginBottom: '1.5rem'}}>Coaching d'Entretien IA</h1>
      <p className="text-muted" style={{maxWidth: '600px', margin: '0 auto 3rem'}}>
        Prépare-toi aux questions pièges et optimise ta posture pour concrétiser ton super CV en contrat.
      </p>
      
      <div style={{background: 'var(--bg-light-grey)', padding: '3rem', borderRadius: '1rem', maxWidth: '800px', margin: '0 auto', textAlign: 'left', border: '1px solid var(--border-color)'}}>
        <h3 style={{marginBottom: '1.5rem'}}>Indique ton profil pour commencer</h3>
        
        <div style={{display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '2rem'}}>
           <input type="text" placeholder="Entité visée (ex: Start-up Tech)" style={{padding: '1rem', border: '1px solid var(--border-color)', borderRadius: '0.5rem'}} />
           <input type="text" placeholder="Poste visé (ex: Développeur React)" style={{padding: '1rem', border: '1px solid var(--border-color)', borderRadius: '0.5rem'}} />
        </div>

        <button className="btn btn-primary" style={{width: '100%'}}>Générer ma simulation d'entretien</button>
      </div>
    </div>
  );
}
