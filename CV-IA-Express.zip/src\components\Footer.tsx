import Link from 'next/link';
import './Footer.css';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-container">
        <div className="footer-brand">
          <Link href="/" className="logo">
            CV IA <span className="text-accent">Express</span>
          </Link>
          <p className="footer-desc">
            Le moyen le plus simple et rapide pour obtenir un CV moderne et professionnel en France.
          </p>
        </div>
        <div className="footer-links-group">
          <div className="footer-col">
            <h4>Produit</h4>
            <Link href="/cv">Créer mon CV</Link>
            <Link href="/lettre">Lettre de motivation</Link>
            <Link href="/tarifs">Tarifs</Link>
          </div>
          <div className="footer-col">
            <h4>Ressources</h4>
            <Link href="/exemples">Exemples de CV</Link>
            <Link href="/blog">Blog</Link>
            <Link href="/entretien">Préparation Entretien</Link>
          </div>
          <div className="footer-col">
            <h4>Légal</h4>
            <Link href="/mentions">Mentions légales</Link>
            <Link href="/cgu">CGU & CGV</Link>
            <Link href="/rgpd">RGPD & Confidentialité</Link>
          </div>
        </div>
      </div>
      <div className="container footer-bottom">
        <p>© {new Date().getFullYear()} CV IA Express. Tous droits réservés.</p>
      </div>
    </footer>
  );
}
