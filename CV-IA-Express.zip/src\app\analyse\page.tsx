import Link from 'next/link';

export default function AnalyseCV() {
  return (
    <div className="container" style={{padding: '5rem 1.5rem', textAlign: 'center', minHeight: '60vh'}}>
      <h1 style={{fontSize: '2.5rem', marginBottom: '1.5rem'}}>Analyse ton CV Existant avec l'IA</h1>
      <p className="text-muted" style={{maxWidth: '600px', margin: '0 auto 3rem'}}>
        Importe ton ancien CV au format PDF. Notre Intelligence Artificielle va l'analyser, repérer les erreurs, et te donner une note sur 100 avec une version corrigée.
      </p>
      
      <div style={{border: '2px dashed var(--border-color)', padding: '4rem 2rem', borderRadius: '1rem', background: 'var(--bg-light-grey)', maxWidth: '600px', margin: '0 auto'}}>
        <div style={{fontSize: '3rem', marginBottom: '1rem'}}>📄</div>
        <h3 style={{marginBottom: '1rem'}}>Glisse ton PDF ici</h3>
        <p className="text-muted" style={{marginBottom: '2rem'}}>ou clique pour importer ton fichier</p>
        <button className="btn btn-primary">Importer mon CV</button>
      </div>
    </div>
  );
}
