import Link from 'next/link';
import './page.css';

export default function LettreMotivation() {
  return (
    <div className="container lettre-container fade-in">
      <div className="lettre-header">
        <h1>Générateur de Lettre de Motivation IA</h1>
        <p className="text-muted">Une lettre sur-mesure, convaincante et naturelle en moins de 30 secondes.</p>
      </div>

      <div className="lettre-content">
        <div className="lettre-form">
          <div className="input-group">
            <label className="input-label">Entreprise ciblée</label>
            <input type="text" className="input-field" placeholder="Ex: LVMH, Google, Boulangerie Dupont..." />
          </div>
          <div className="input-group">
            <label className="input-label">Poste visé</label>
            <input type="text" className="input-field" placeholder="Ex: Chef de projet marketing" />
          </div>
          <div className="input-group">
            <label className="input-label">Ton souhaité</label>
            <select className="input-field" style={{appearance: 'none'}}>
              <option>Professionnel & Corporate</option>
              <option>Dynamique & Jeune</option>
              <option>Créatif & Original</option>
              <option>Premium & Luxe</option>
            </select>
          </div>
          <div className="input-group">
            <label className="input-label">Pourquoi cette entreprise ? (Mots clés)</label>
            <textarea className="input-field" rows={3} placeholder="Ex: Leader marché, valeurs éthiques, challenge technique..."></textarea>
          </div>
          <div className="input-group">
            <label className="input-label">Tes atouts principaux</label>
            <textarea className="input-field" rows={3} placeholder="Ex: 3 ans expérience, maîtrise Python, bilingue anglais..."></textarea>
          </div>
          
          <button className="btn btn-primary btn-large cta-lettre">
            🪄 Rédiger ma lettre avec l'IA
          </button>
        </div>
        
        <div className="lettre-preview-container">
          <div className="lettre-preview-placeholder">
            <div className="l-header">
               <div className="l-info">Ton Prénom Nom<br/>Ton Email<br/>Ton Téléphone</div>
               <div className="l-info right">Nom Entreprise<br/>Adresse Entreprise<br/>Date</div>
            </div>
            <div className="l-title">Objet : Candidature au poste de [Poste visé]</div>
            <div className="l-body">
               <div className="l-line"></div>
               <div className="l-line"></div>
               <div className="l-line short"></div>
               <br/>
               <div className="l-line"></div>
               <div className="l-line"></div>
               <div className="l-line"></div>
               <div className="l-line short"></div>
            </div>
            <div className="l-placeholder-text">L'aperçu de ta lettre magique apparaîtra ici.</div>
          </div>
        </div>
      </div>
    </div>
  );
}
