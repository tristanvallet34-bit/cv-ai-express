import { auth } from '@/auth';
import { redirect } from 'next/navigation';
import Link from 'next/link';

export default async function Dashboard() {
  const session = await auth();

  if (!session?.user) {
    redirect('/login');
  }

  return (
    <div className="container" style={{padding: '5rem 1.5rem', minHeight: '80vh'}}>
      <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '3rem', paddingBottom: '2rem', borderBottom: '1px solid var(--border-color)'}}>
        <div>
          <h1 style={{fontSize: '2.5rem', marginBottom: '0.5rem'}}>Bonjour, {session.user.name || session.user.email} 👋</h1>
          <p className="text-muted">Gérez vos CV générés et vos lettres de motivation depuis cet espace.</p>
        </div>
        <div>
           <Link href="/cv" className="btn btn-primary">+ Créer un nouveau CV</Link>
        </div>
      </div>

      <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem'}}>
        <div style={{border: '1px dashed var(--border-color)', borderRadius: '1rem', padding: '3rem', textAlign: 'center', background: 'var(--bg-light-grey)'}}>
           <h3 style={{color: 'var(--text-muted)'}}>Aucun CV pour le moment</h3>
           <Link href="/cv" className="btn btn-outline" style={{marginTop: '1.5rem'}}>Créer mon premier CV</Link>
        </div>
      </div>
    </div>
  );
}
