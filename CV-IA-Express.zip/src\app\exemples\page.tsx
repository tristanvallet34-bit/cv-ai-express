import Link from 'next/link';
import './page.css';

export default function Exemples() {
  const exemples = [
    { title: "CV Étudiant", desc: "Parfait pour un premier stage", type: "student" },
    { title: "CV Commerce", desc: "Axé sur les résultats et KPIs", type: "pro" },
    { title: "CV Serveur", desc: "Mise en avant du savoir-être", type: "classic" },
    { title: "CV Alternance", desc: "Format hybride école/entreprise", type: "pro" },
    { title: "CV Luxe", desc: "Design épuré et minimaliste", type: "luxury" },
    { title: "CV Débutant", desc: "Met en valeur les soft skills", type: "student" },
  ];

  return (
    <div className="container exemples-container fade-in">
      <div className="section-header">
        <h1>Exemples de CV générés par l'IA</h1>
        <p className="text-muted" style={{fontSize: '1.25rem', marginTop: '1rem'}}>
          Découvre la qualité des modèles créés automatiquement par CV IA Express.
        </p>
      </div>

      <div className="exemples-grid">
        {exemples.map((ex, i) => (
          <div key={i} className="exemple-card">
            <div className={`exemple-visual type-${ex.type}`}>
               {/* Decorative CV structure */}
               <div className="e-head"></div>
               <div className="e-body"></div>
               <div className="e-body short"></div>
            </div>
            <div className="exemple-info">
              <h3>{ex.title}</h3>
              <p>{ex.desc}</p>
              <Link href="/cv" className="btn btn-outline" style={{width: '100%', marginTop: '1rem'}}>
                Utiliser ce modèle
              </Link>
            </div>
          </div>
        ))}
      </div>

      <div className="cta-section" style={{borderRadius: '1rem', marginTop: '4rem', padding: '4rem 2rem'}}>
        <h2>L'un de ces modèles te plaît ?</h2>
        <p>L'IA adaptera les couleurs et la mise en page à ton profil unique.</p>
        <Link href="/cv" className="btn btn-primary btn-large cta-bump" style={{marginTop: '2rem'}}>
          Créer mon CV
        </Link>
      </div>
    </div>
  );
}
