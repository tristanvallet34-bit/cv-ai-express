import Link from 'next/link';
import './page.css';

export default function Home() {
  return (
    <div className="home fade-in">
      {/* SECTION HERO */}
      <section className="hero-section">
        <div className="container hero-container">
          <div className="hero-content">
            <h1 className="hero-title">
              Crée un CV professionnel en <span className="text-accent">2 minutes</span> avec l'IA
            </h1>
            <p className="hero-subtitle">
              Plus besoin de galérer sur Word. Réponds à quelques questions et récupère un CV moderne prêt à envoyer.
            </p>
            <div className="hero-actions">
              <Link href="/cv" className="btn btn-primary btn-large">Créer gratuitement</Link>
              <Link href="/exemples" className="btn btn-outline btn-large">Voir exemples</Link>
            </div>
            <div className="hero-trust">
              <div className="stars">★★★★★ 4.9/5</div>
              <p>+12 000 utilisateurs • Utilisé partout en France</p>
            </div>
          </div>
          <div className="hero-visual">
            <div className="mockup-placeholder">
              <div className="mockup-screen">
                <div className="cv-preview">
                  <div className="cv-header-line"></div>
                  <div className="cv-profile-circle"></div>
                  <div className="cv-divider"></div>
                  <div className="cv-body">
                    <div className="cv-line"></div>
                    <div className="cv-line short"></div>
                    <br/>
                    <div className="cv-line"></div>
                    <div className="cv-line short"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION COMMENT CA MARCHE */}
      <section className="how-it-works bg-light">
        <div className="container">
          <div className="section-header">
            <h2>Génère ton CV en 3 étapes simples</h2>
          </div>
          <div className="steps-grid">
            <div className="step-card">
              <div className="step-number">1</div>
              <h3>Remplis ton profil</h3>
              <p>Réponds à quelques questions simples sur ton parcours.</p>
            </div>
            <div className="step-card">
              <div className="step-number">2</div>
              <h3>L'IA rédige & métropolise</h3>
              <p>L'intelligence artificielle rédige et applique un design premium instantanément.</p>
            </div>
            <div className="step-card">
              <div className="step-number">3</div>
              <h3>Télécharge & Postule</h3>
              <p>Exporte ton CV en PDF Haute Définition et postule sereinement.</p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION BÉNÉFICES */}
      <section className="benefits-section">
        <div className="container">
          <div className="benefits-grid">
            <div className="benefit-item">✔️ Gagne du temps précieux</div>
            <div className="benefit-item">✔️ Design professionnel validé par RH</div>
            <div className="benefit-item">✔️ Augmente tes chances d'entretien</div>
            <div className="benefit-item">✔️ 100% compatible mobile</div>
            <div className="benefit-item">✔️ Prêt en seulement 2 minutes</div>
            <div className="benefit-item">✔️ Lettres de motivation incluses</div>
          </div>
        </div>
      </section>

      {/* SECTION AVANT / APRES */}
      <section className="before-after">
        <div className="container">
          <div className="section-header">
            <h2>Passe d'un profil amateur à un CV qui convertit</h2>
          </div>
          <div className="ba-grid">
            <div className="ba-card before">
              <div className="ba-tag tag-red">Classique Word</div>
              <div className="cv-mockup m-old">
                 <div className="bad-design"></div>
              </div>
            </div>
            <div className="ba-card after">
              <div className="ba-tag tag-green">Avec CV IA Express</div>
              <div className="cv-mockup m-new">
                 <div className="good-design"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION TÉMOIGNAGES */}
      <section className="testimonials">
        <div className="container">
          <div className="section-header">
            <h2>Ils ont trouvé leur emploi grâce à nous</h2>
          </div>
          <div className="testi-grid">
            <div className="testi-card">
              <div className="testi-stars">★★★★★</div>
              <p className="testi-quote">"J'ai trouvé mon alternance en 10 jours après avoir refait mon CV ici. Le design est ouf."</p>
              <div className="testi-author">- Thomas, 21 ans (Alternant)</div>
            </div>
            <div className="testi-card">
              <div className="testi-stars">★★★★★</div>
              <p className="testi-quote">"Incroyable, simple et rapide. Les lettres de motivation générées sont parfaites."</p>
              <div className="testi-author">- Sarah, 26 ans (Marketing)</div>
            </div>
            <div className="testi-card">
              <div className="testi-stars">★★★★★</div>
              <p className="testi-quote">"Mon CV faisait vraiment amateur avant, maintenant on me répond !"</p>
              <div className="testi-author">- Julien, 30 ans (Reconversion)</div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION URGENCE / CTA FINAL */}
      <section className="cta-section">
        <div className="container cta-container">
          <h2>Chaque jour sans bon CV = des opportunités perdues.</h2>
          <p>N'attends plus. Rejoins les 12 000+ utilisateurs qui ont boosté leur carrière.</p>
          <Link href="/cv" className="btn btn-primary btn-large cta-bump">Créer mon CV maintenant</Link>
        </div>
      </section>
    </div>
  );
}
