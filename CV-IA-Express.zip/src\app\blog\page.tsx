import Link from 'next/link';

export default function Blog() {
  const articles = [
    { title: "Comment faire un CV en 2026 qui tape dans l'œil des RH", date: "12 Avril 2026", cat: "Conseils CV" },
    { title: "Le meilleur CV étudiant pour décrocher un stage", date: "5 Avril 2026", cat: "Étudiant" },
    { title: "Top 5 des erreurs qui font refuser votre CV immédiatement", date: "28 Mars 2026", cat: "Erreurs à éviter" },
    { title: "Exemple parfait d'une lettre de motivation pour une alternance", date: "15 Mars 2026", cat: "Lettre" }
  ];

  return (
    <div className="container" style={{padding: '5rem 1.5rem', minHeight: '60vh'}}>
      <div style={{textAlign: 'center', marginBottom: '4rem'}}>
        <h1 style={{fontSize: '2.5rem', marginBottom: '1.5rem'}}>Le Blog Carrière</h1>
        <p className="text-muted" style={{maxWidth: '600px', margin: '0 auto'}}>
          Insights, conseils RH et astuces SEO appliquées à la recherche d'emploi.
        </p>
      </div>
      
      <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem'}}>
        {articles.map((art, i) => (
          <div key={i} style={{border: '1px solid var(--border-color)', borderRadius: '1rem', overflow: 'hidden', transition: 'transform 0.2s', cursor: 'pointer'}} className="blog-card">
             <div style={{height: '200px', background: 'var(--bg-light-grey)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)'}}>
                [Image Article]
             </div>
             <div style={{padding: '1.5rem'}}>
                <span style={{color: 'var(--accent-blue)', fontWeight: 600, fontSize: '0.875rem', marginBottom: '0.5rem', display: 'block'}}>{art.cat}</span>
                <h3 style={{marginBottom: '1rem', fontSize: '1.25rem', lineHeight: 1.4}}>{art.title}</h3>
                <p className="text-muted" style={{fontSize: '0.875rem'}}>{art.date}</p>
             </div>
          </div>
        ))}
      </div>
    </div>
  );
}
