import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import OpenAI from 'openai';

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
    }

    const { text, type } = await req.json();

    if (!process.env.OPENAI_API_KEY) {
      // Mock mode
      await new Promise(r => setTimeout(r, 1500));
      return NextResponse.json({ optimizedText: `[IA] Texte professionnellement optimisé basé sur : "${text.substring(0, 50)}..."` });
    }

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    
    let prompt = "";
    if (type === "experience") {
      prompt = `Tu es un recruteur expert. Reformule ces missions professionnelles pour les rendre plus impactantes, axées sur les résultats et professionnelles. Ne garde que l'essentiel en liste à puces : \n\n${text}`;
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
    });

    return NextResponse.json({ optimizedText: response.choices[0].message.content });

  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erreur IA" }, { status: 500 });
  }
}
