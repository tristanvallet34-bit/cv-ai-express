import { NextResponse } from 'next/server';
import OpenAI from 'openai';

export async function POST(req: Request) {
  try {
    const data = await req.json();

    if (!process.env.OPENAI_API_KEY) {
      // Mock mode
      await new Promise(r => setTimeout(r, 2000));
      return NextResponse.json({ 
        letter: `Objet: Candidature\n\nMadame, Monsieur,\n\nCeci est une lettre générée par l'IA simulée pour le poste de ${data.role} chez ${data.org}. En condition réelle, GPT-4 rédigera ici une lettre sur-mesure basée sur vos atouts.\n\nCordialement.` 
      });
    }

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    
    const prompt = `Rédige une lettre de motivation complète et percutante pour le poste de ${data.role} chez ${data.targetOrg}. 
    Ton à utiliser: ${data.tone}.
    Atouts du candidat: ${data.assets}.
    Intérêt pour l'entreprise: ${data.interest}.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
    });

    return NextResponse.json({ letter: response.choices[0].message.content });

  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erreur IA" }, { status: 500 });
  }
}
