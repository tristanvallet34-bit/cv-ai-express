"use client";

import { signIn } from "next-auth/react";
import { useState } from "react";
import './page.css';
import Link from "next/link";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await signIn("credentials", { email, password, callbackUrl: '/dashboard' });
  };

  return (
    <div className="login-container fade-in">
      <div className="login-box">
        <div className="login-header">
          <h1>Bon retour parmi nous</h1>
          <p className="text-muted">Connecte-toi pour retrouver tes CV.</p>
        </div>
        
        <form onSubmit={handleSubmit} className="login-form">
          <div className="input-group">
            <label className="input-label">Email</label>
            <input 
              type="email" 
              className="input-field" 
              placeholder="jean@example.com" 
              value={email}
              onChange={e => setEmail(e.target.value)}
              required 
            />
          </div>
          <div className="input-group">
            <label className="input-label">Mot de passe</label>
            <input 
              type="password" 
              className="input-field" 
              placeholder="••••••••" 
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
            <Link href="#" className="forgot-password">Mot de passe oublié ?</Link>
          </div>
          
          <button type="submit" className="btn btn-primary btn-large login-btn" disabled={loading}>
            {loading ? "Connexion..." : "Se connecter"}
          </button>
        </form>

        <div className="login-divider"><span>ou</span></div>
        <button className="btn btn-outline login-btn" style={{marginBottom: "1rem"}}>
           🔑 Connexion avec Google
        </button>

        <div className="login-footer">
          Tu n'as pas de compte ? <Link href="/register">Inscris-toi</Link>
        </div>
      </div>
    </div>
  );
}
