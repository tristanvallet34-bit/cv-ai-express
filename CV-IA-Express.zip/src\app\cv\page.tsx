"use client";

import { useState, useRef } from 'react';
import './page.css';

export default function CVAdvancedEditor() {
  const [data, setData] = useState({
    firstName: '', lastName: '', age: '', city: '', phone: '', email: '',
    title: '', contract: 'CDI',
    summary: '',
    experiences: [{ id: 1, company: '', role: '', dates: '', desc: '' }],
    educations: [{ id: 1, degree: '', school: '', year: '' }],
    skills: '', 
    themeColor: '#0056ff',
    font: 'Outfit'
  });

  const [aiLoading, setAiLoading] = useState<number | null>(null);
  const pdfRef = useRef<HTMLDivElement>(null);

  const handleExport = async () => {
    const html2pdf = (await import('html2pdf.js')).default;
    const element = pdfRef.current;
    if (element) {
      const opt = {
        margin:       0,
        filename:     `CV_${data.firstName}_${data.lastName}.pdf`,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2 },
        jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
      };
      html2pdf().set(opt).from(element).save();
    }
  };

  const optimizeExperience = async (index: number) => {
    setAiLoading(index);
    try {
      const res = await fetch('/api/ai/optimize-cv', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: data.experiences[index].desc, type: 'experience' })
      });
      const json = await res.json();
      if (json.optimizedText) {
        const newExps = [...data.experiences];
        newExps[index].desc = json.optimizedText;
        setData({ ...data, experiences: newExps });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setAiLoading(null);
    }
  };

  return (
    <div className="builder-layout fade-in">
      {/* LEFT: EDITOR */}
      <div className="builder-sidebar">
        <h2>🛠️ Éditeur de CV</h2>
        
        <div className="editor-section">
          <h3>Profil</h3>
          <input className="input-field mb-2" placeholder="Prénom" value={data.firstName} onChange={e => setData({...data, firstName: e.target.value})} />
          <input className="input-field mb-2" placeholder="Nom" value={data.lastName} onChange={e => setData({...data, lastName: e.target.value})} />
          <input className="input-field mb-2" placeholder="Titre (ex: Développeur)" value={data.title} onChange={e => setData({...data, title: e.target.value})} />
          <input className="input-field mb-2" placeholder="Email" value={data.email} onChange={e => setData({...data, email: e.target.value})} />
          <input className="input-field mb-2" placeholder="Téléphone / Ville" value={data.phone} onChange={e => setData({...data, phone: e.target.value})} />
        </div>

        <div className="editor-section">
          <h3>Expériences</h3>
          {data.experiences.map((exp, i) => (
            <div key={exp.id} className="edit-block">
              <input className="input-field mb-2" placeholder="Poste" value={exp.role} onChange={e => { const a=[...data.experiences]; a[i].role=e.target.value; setData({...data, experiences: a}); }}/>
              <input className="input-field mb-2" placeholder="Entreprise & Dates" value={exp.company} onChange={e => { const a=[...data.experiences]; a[i].company=e.target.value; setData({...data, experiences: a}); }}/>
              <textarea className="input-field mb-2" placeholder="Missions..." rows={3} value={exp.desc} onChange={e => { const a=[...data.experiences]; a[i].desc=e.target.value; setData({...data, experiences: a}); }}/>
              <button className="btn btn-outline ai-btn" onClick={() => optimizeExperience(i)} disabled={aiLoading === i}>
                {aiLoading === i ? "⏳ Optimisation..." : "✨ Optimiser missions avec l'IA"}
              </button>
            </div>
          ))}
          <button className="btn btn-outline mt-2" onClick={() => setData({...data, experiences: [...data.experiences, {id: Date.now(), company:'', role:'', dates:'', desc:''}]})}>+ Ajouter</button>
        </div>

        <div className="editor-section">
          <h3>Design</h3>
          <div style={{display:'flex', gap:'1rem'}}>
             <button className="color-swatch" style={{background: '#0f172a'}} onClick={()=>setData({...data, themeColor: '#0f172a'})}></button>
             <button className="color-swatch" style={{background: '#0056ff'}} onClick={()=>setData({...data, themeColor: '#0056ff'})}></button>
             <button className="color-swatch" style={{background: '#10b981'}} onClick={()=>setData({...data, themeColor: '#10b981'})}></button>
             <button className="color-swatch" style={{background: '#ef4444'}} onClick={()=>setData({...data, themeColor: '#ef4444'})}></button>
          </div>
        </div>
      </div>

      {/* RIGHT: REALTIME PREVIEW */}
      <div className="builder-preview-area">
        <div className="preview-toolbar">
           <button className="btn btn-outline">💾 Sauvegarder Brouillon</button>
           <button className="btn btn-primary" onClick={handleExport}>📥 Exporter PDF HD</button>
        </div>
        
        <div className="preview-paper-wrapper">
          <div className="cv-document" ref={pdfRef} style={{ fontFamily: data.font }}>
            {/* Header CV */}
            <div className="cv-doc-header" style={{ borderBottomColor: data.themeColor }}>
               <h1 style={{ color: data.themeColor }}>{data.firstName || 'Votre'} {data.lastName || 'Nom'}</h1>
               <h2 className="cv-doc-title">{data.title || 'Titre du Poste'}</h2>
               <div className="cv-doc-contact">
                 <span>{data.email || 'email@exemple.com'}</span> | <span>{data.phone || '06 00 00 00 00'}</span>
               </div>
            </div>

            <div className="cv-doc-body">
               <div className="cv-doc-main">
                  {/* Experiences */}
                  <h3 className="cv-section-title" style={{ color: data.themeColor }}>Expériences Professionnelles</h3>
                  {data.experiences.map((exp, i) => (
                    <div key={i} className="cv-item">
                       <div className="cv-item-header">
                         <h4>{exp.role || 'Rôle'}</h4>
                         <span className="cv-item-date">{exp.company || 'Entreprise | Année'}</span>
                       </div>
                       <div className="cv-item-desc" style={{whiteSpace: 'pre-wrap'}}>{exp.desc || 'Description de la mission...'}</div>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
